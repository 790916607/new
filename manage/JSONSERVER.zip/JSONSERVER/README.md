//获取所有用户信息
http://localhost:3000/users

//获取id为1的用户信息
http://localhost:3000/users/1

//获取公司的所有信息
http://localhost:3000/companies

//获取单个公司信息（例如id为1的公司）
http://localhost:3000/companies/1

//获取所有公司id为3的用户
http://localhost:3000/companies/3/users

//根据公司名字获取信息
http://localhost:3000/companies?name=BaiDu

//根据多个名字获取公司信息
http://localhost:3000/companies?name=BaiDu&name=Apple

//获取一页中只有两条数据
http://localhost:3000/companies?_page=1&_limit=2

//根据公司名字升序排序
http://localhost:3000/companies?sort=name&_order=asc

根据公司名字降序排序
http://localhost:3000/companies?sort=name&_order=desc

获取年龄19以及19以上的用户的数据
http://localhost:3000/users?age_gte=19

获取年龄16-19的用户的数据
http://localhost:3000/users?age_gte=16&age_lte=19

搜索用户信息
http://localhost:3000/users?q=w