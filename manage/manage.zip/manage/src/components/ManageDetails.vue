<template>
  <div class="deatils container">
      <router-link to="/" class="btn btn-default">返回主页</router-link>
      <h1 class="page-header">
          {{manage.name}}
          <span class="pull-right">
              <router-link class="btn btn-primary" :to="'/edit/'+manage.id">编辑</router-link>
              <button class="btn btn-danger" @click="deleteManage(manage.id)">删除</button>
          </span>
      </h1>
      <ul class="list-group">
          <li class="list-group-item"><span class="glyphicon glyphicon-earphone">{{manage.phone}}</span></li>
          <li class="list-group-item"><span class="glyphicon glyphicon-envelope">{{manage.email}}</span></li>
      </ul>
      <ul class="list-group">
          <li class="list-group-item"><span class="glyphicon glyphicon-book">{{manage.education}}</span></li>
          <li class="list-group-item"><span class="glyphicon glyphicon-home">{{manage.graduationschool}}</span></li>
      </ul>
      <ul class="list-group">
          <li class="list-group-item"><span class="glyphicon glyphicon-bookmark">{{manage.profession}}</span></li>
          <li class="list-group-item"><span class="glyphicon glyphicon-edit">{{manage.profile}}</span></li>
      </ul>
  </div>
</template>

<script>
export default {
  name: "managedetails",
  data() {
    return {
      manage: ""
    };
  },
  methods: {
    fetManages(id) {
      this.$axios.get("http://localhost:3000/users/"+id).then(response => {
        //   console.log("dsa")
        this.manage = response.data;
      });
    },
    deleteManage(id){
        // console.log(id)
        this.$axios.delete("http://localhost:3000/users/"+id).then(response=>{
            this.$router.push({path:"/",query:{alert:"用户删除成功"}});
        })
    }
  },
  created(){
      this.fetManages(this.$route.params.id);
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>