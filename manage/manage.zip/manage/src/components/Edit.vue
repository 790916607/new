<template>
  <div class="edit container">
      <Alert v-if="alert" :message="alert"></Alert>
      <h1 class="page.heard">编辑用户</h1>
      <form action="" @submit="updateManage">
          <div class="well">
              <h4>用户信息</h4>
              <div class="form-group">
                  <label>姓名</label>
                  <input type="text" class="form-control" placeholder="name" v-model="manage.name">
              </div>
              <div class="form-group">
                  <label>电话</label>
                  <input type="text" class="form-control" placeholder="phone" v-model="manage.phone">
              </div>
              <div class="form-group">
                  <label>邮箱</label>
                  <input type="text" class="form-control" placeholder="email" v-model="manage.email">
              </div>
              <div class="form-group">
                  <label>学历</label>
                  <input type="text" class="form-control" placeholder="education" v-model="manage.education">
              </div>
              <div class="form-group">
                  <label>毕业学校</label>
                  <input type="text" class="form-control" placeholder="graduationschool" v-model="manage.graduationschool">
              </div>
              <div class="form-group">
                  <label>职业</label>
                  <input type="text" class="form-control" placeholder="profession" v-model="manage.profession">
              </div>
              <div class="form-group">
                  <label>个人简介</label>
                  <textarea class="form-control" rows="10" v-model="manage.profile"></textarea>
              </div>
          </div>
          <button type="submit" class="btn btn-primary">添加</button>
      </form>
  </div>
</template>

<script>
import Alert from "./Alert"
export default {
  name: 'add',
  data () {
    return {
        manage:{},
        alert:""
    }
  },
  methods:{
      fetchManage(id){
          this.$axios.get("http://localhost:3000/users/"+id).then(response=>{
            //   console.log(response);
            this.manage = response.data;
          })
      },
      updateManage(e){
        //   console.log(147)
        if(!this.manage.name || !this.manage.phone || !this.manage.email){
            // console.log("请添加对应的信息")
            this.alert = "请添加的对应的信息"

        }else{
            let updateManage = {
                name:this.manage.name,
                phoen:this.manage.phone,
                email:this.manage.email,
                education:this.manage.education,
                graduationschool:this.manage.graduationschool,
                profession:this.manage.profession,
                profile:this.manage.profile
            }
            this.$axios.put("http://localhost:3000/users/"+this.$route.params.id,updateManage)
            .then((response) =>{
                // console.log(response)
                this.$router.push({path:"/", query:{alert:"用户信息更新成功!"}});
            })
          e.preventDefault();

        }
          e.preventDefault();
      }
  },
  components:{
      Alert
  },
  created(){
      this.fetchManage(this.$route.params.id);
  }
  
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>