<template>
  <div class="about container">
      <h1 class="page-header">
        姓名：王伟
        <br>
        <br>
        联系电话：13629205146
      </h1>
  </div>
</template>

<script>
export default {
  name: 'about',
  data () {
    return {
     
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>