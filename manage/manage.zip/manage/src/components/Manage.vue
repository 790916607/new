<template>
  <div class="manage container">
      <Alert v-if="alert" v-bind:message="alert"></Alert>
      <h1 class="page-header">用户管理系统</h1>
      <input type="text" class="form-control" placeholder="搜索" v-model="filterInput">
      <br>
      <table class="table table-strped">
          <thead>
              <tr>
                  <th>姓名</th>
                  <th>电话</th>
                  <th>邮箱</th>
              </tr>
          </thead>

          <tbody>
              <tr v-for="manage in filterBy(manages,filterInput)">
                  <td>{{manage.name}}</td>
                  <td>{{manage.phone}}</td>
                  <td>{{manage.email}}</td>
                  <td><router-link class="btn btn-default" v-bind:to="'/manage/'+manage.id">详情</router-link></td>
              </tr>
          </tbody>
      </table>
  </div>
</template>

<script>
import Alert from './Alert'
export default {
  name: 'manage',
  data () {
    return {
     manages:[],
     alert:"",
     filterInput:""
    }
  },
  methods:{
      fetManages(){
          this.$axios.get("http://localhost:3000/users")
          .then((response)=>{
            //   console.log(response);
            this.manages = response.data;
          })
      },
      filterBy(manages,value){
          return manages.filter(function(manage){
              return manage.name.match(value);
          })
      }
  },
  created(){
      if(this.$route.query.alert){
          this.alert = this.$route.query.alert;
      }
      this.fetManages();
  },
    updated(){
      this.fetManages();
  },
  components:{
      Alert
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
