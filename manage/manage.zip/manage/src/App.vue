<template>
  <div id="app">


  </div>
</template>

<script>
// import HelloWorld from './components/HelloWorld'

export default {
  name: 'App',
  components: {
    
  }
}
</script>

<style>

</style>
